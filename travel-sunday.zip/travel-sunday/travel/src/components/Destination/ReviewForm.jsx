import { useState } from "react";
import axios from "axios";

export default function ReviewForm({ type, id, onReviewAdded, token }) {
  const [user, setUser] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [activities, setActivities] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await axios.post("http://localhost:5000/reviews", {
        type,
        id,
        user,
        rating,
        comment,
        activities: activities.split(",").map(a => a.trim()).filter(a => a.length > 0),
      }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setUser("");
      setRating(5);
      setComment("");
      if (onReviewAdded) onReviewAdded();
    } catch (err) {
      if (err.response?.status === 401) {
        alert("Please log in to submit a review.");
      } else {
        setError("Failed to submit review");
      }
      console.error("Error submitting review:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: "500px", marginTop: "1rem" }}>
      <div className="mb-3">
        <label htmlFor="user" className="form-label">Name</label>
        <input
          id="user"
          type="text"
          className="form-control"
          value={user}
          onChange={(e) => setUser(e.target.value)}
          placeholder="Your name"
          required
          style={{ borderRadius: "8px", borderColor: "#135677" }}
        />
      </div>

      <div className="mb-3">
        <label htmlFor="rating" className="form-label">Rating</label>
        <select
          id="rating"
          className="form-select"
          value={rating}
          onChange={(e) => setRating(Number(e.target.value))}
          required
          style={{ borderRadius: "8px", borderColor: "#135677" }}
        >
          {[5,4,3,2,1].map((r) => (
            <option key={r} value={r}>{r} Star{r > 1 ? "s" : ""}</option>
          ))}
        </select>
      </div>

      <div className="mb-3">
        <label htmlFor="comment" className="form-label">Comment</label>
        <textarea
          id="comment"
          className="form-control"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Write your review here"
          rows={4}
          required
          style={{ borderRadius: "8px", borderColor: "#135677" }}
        />
      </div>
      <div className="mb-3">
        <label htmlFor="activities" className="form-label">Activities (comma separated)</label>
        <input
          id="activities"
          type="text"
          className="form-control"
          value={activities}
          onChange={(e) => setActivities(e.target.value)}
          placeholder="e.g. Surfing, Hiking"
          style={{ borderRadius: "8px", borderColor: "#135677" }}
        />
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <button
        type="submit"
        className="btn"
        style={{
          backgroundColor: "#135677",
          color: "white",
          borderRadius: "8px",
          padding: "10px 20px",
          fontWeight: "bold",
          width: "100%",
        }}
        disabled={loading}
      >
        {loading ? "Submitting..." : "Submit Review"}
      </button>
    </form>
  );
}
