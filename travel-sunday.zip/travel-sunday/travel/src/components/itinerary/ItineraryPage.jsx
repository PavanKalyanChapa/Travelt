import React, { useEffect, useState } from "react";
import axios from "axios";
import ItineraryList from "./ItineraryList";

const ItineraryPage = () => {
  const [itineraries, setItineraries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchItineraries = async () => {
      try {
        const response = await axios.get("http://localhost:5000/trip-itineraries/"); // Adjust endpoint if needed
        if (response.data && Array.isArray(response.data.itineraries)) {
          setItineraries(response.data.itineraries);
        } else if (Array.isArray(response.data)) {
          setItineraries(response.data);
        } else {
          setItineraries([]);
        }
      } catch (err) {
        setError("Failed to fetch itineraries");
      } finally {
        setLoading(false);
      }
    };

    fetchItineraries();
  }, []);

  if (loading) return <div>Loading itineraries...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container my-4">
      <h2 className="mb-4">All Trip Itineraries</h2>
      {itineraries.length === 0 ? (
        <p>No itineraries found.</p>
      ) : (
        <ItineraryList itineraries={itineraries} />
      )}
    </div>
  );
};

export default ItineraryPage;
