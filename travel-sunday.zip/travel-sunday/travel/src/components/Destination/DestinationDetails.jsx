import { useParams, useNavigate } from "react-router-dom";

import { useEffect, useState } from "react";

import axios from "axios";

import { FaArrowLeft, FaStar } from "react-icons/fa";

import ItineraryList from "../itinerary/ItineraryList";

import ReviewForm from "./ReviewForm";

import { useAuth } from '../../contexts/AuthContext';




export default function DestinationDetails() {

    const { id } = useParams();

    const navigate = useNavigate();

    const { isAuthenticated, token } = useAuth();

    const [destination, setDestination] = useState(null);

    const [activeTab, setActiveTab] = useState("overview");

    const [itineraries, setItineraries] = useState([]);

    const [loadingItinerary, setLoadingItinerary] = useState(true);

    const [isFavorite, setIsFavorite] = useState(false);

    const [loadingFavorite, setLoadingFavorite] = useState(false);

    const [reviews, setReviews] = useState([]);

    const [loadingReviews, setLoadingReviews] = useState(true);

    const [reviewsError, setReviewsError] = useState(null);

    const fetchReviews = async () => {
        setLoadingReviews(true);
        setReviewsError(null);
        try {
            const response = await axios.get("http://localhost:5000/reviews", {
                params: { type: "destination-guide", id }
            });
            setReviews(response.data.reviews || []);
        } catch (err) {
            setReviewsError("Failed to load reviews");
            console.error("Error fetching reviews:", err);
        } finally {
            setLoadingReviews(false);
        }
    };




    useEffect(() => {

        axios

            .get("http://localhost:5000/destinations")

            .then((res) => {

                const match = res.data.find((d) => d.destinationId === Number(id));

                if (match) {

                    setDestination(match);

                } else {

                    setDestination("not-found");

                }

            })

            .catch(() => setDestination("not-found"));

    }, [id]);




    useEffect(() => {
        const fetchItineraries = async () => {
            try {
                const response = await fetch(`http://localhost:5000/trip-itineraries/${id}`);
                const data = await response.json();
                setItineraries(data.itineraries || []);
                setLoadingItinerary(false);
            } catch (error) {
                console.error("Error in fetching itineraries", error);
                setLoadingItinerary(false);
            }
        };
        fetchItineraries();
        fetchReviews();
    }, [id]);

    // Check if destination is already in favorites
    useEffect(() => {
        const checkFavoriteStatus = async () => {
            if (!isAuthenticated || !token) return;
            try {
                const response = await axios.get("http://localhost:5000/favorites", {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const favorites = response.data.favorites || [];
                const isFav = favorites.some(fav => fav.type === "destination-guide" && fav.id === Number(id));
                setIsFavorite(isFav);
            } catch (error) {
                console.error("Error checking favorite status:", error);
            }
        };
        if (destination && isAuthenticated) {
            checkFavoriteStatus();
        }
    }, [id, destination, isAuthenticated, token]);

    const toggleFavorite = async () => {
        if (loadingFavorite) return;

        // Check authentication before attempting to save favorite
        if (!isAuthenticated) {
            // Show alert and redirect to login page
            alert("Please log in to save favorites.");
            setTimeout(() => navigate("/login"), 100);
            return;
        }

        setLoadingFavorite(true);
        try {
            if (isFavorite) {
                // Remove from favorites
                await axios.delete(`http://localhost:5000/favorites/${id}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setIsFavorite(false);
            } else {
                // Add to favorites
                await axios.post("http://localhost:5000/favorites", {
                    type: "destination-guide",
                    id: Number(id)
                }, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setIsFavorite(true);
            }
        } catch (error) {
            console.error("Error toggling favorite:", error);
            if (error.response?.status === 401) {
                alert("Please log in to save favorites.");
                setTimeout(() => navigate("/login"), 100);
            } else {
                alert("Error saving favorite. Please try again.");
            }
        } finally {
            setLoadingFavorite(false);
        }
    };




    if (destination === "not-found") {

        return (

            <div className="container my-5 text-center">

                <h3>Destination guide not found</h3>

                <button className="btn btn-primary mt-3" onClick={() => navigate(-1)}>

                    Go Back

                </button>

            </div>

        );

    }




    if (!destination) {

        return (

            <div className="container text-center my-5">

                <div className="spinner-border text-primary" />

                <p>Loading...</p>

            </div>

        );

    }




    return (

        <div className="container my-4" style={{ width: "100vw", maxWidth: "100vw", padding: "0 15px" }}>
            {/* Back button */}
            <button className="btn btn-outline-secondary mb-3" onClick={() => navigate("/")}>
                <FaArrowLeft /> Back
            </button>

            {/* Image */}
            <div style={{ marginBottom: "20px" }}>
                <img
                    src={destination.imageUrl || process.env.PUBLIC_URL + "/BAL.jpg"}
                    alt={destination.destinationName}
                    style={{ width: "100%", borderRadius: "10px", objectFit: "cover", maxHeight: "300px" }} />
            </div>

            {/* Title and location */}
            <h2 style={{ fontWeight: "bold", marginBottom: "5px" }}>{destination.destinationName}, {destination.country || "Unknown"}</h2>

            {/* Rating and reviews */}
            <div style={{ display: "flex", alignItems: "center", marginBottom: "10px" }}>
                <div style={{ backgroundColor: "#007bff", color: "white", padding: "5px 10px", borderRadius: "5px", marginRight: "10px" }}>
                    {destination.rating ? destination.rating.toFixed(1) : "N/A"} <FaStar />
                </div>
                <div style={{ color: "#555" }}>
                    Based on {destination.reviews ? destination.reviews.length : 0} reviews
                </div>
            </div>

            {/* Description */}
            <p style={{ marginBottom: "15px", color: "#333" }}>{destination.destinationSummary}</p>

            {/* Save and Share buttons */}
            <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
                <button
                    style={{ backgroundColor: "#e74c3c", color: "white", border: "none", padding: "8px 15px", borderRadius: "5px", cursor: "pointer" }}
                    onClick={toggleFavorite}
                    disabled={loadingFavorite}
                >
                    {loadingFavorite ? "Saving..." : "❤️ Save"}
                </button>
                <button style={{ backgroundColor: "#007bff", color: "white", border: "none", padding: "8px 15px", borderRadius: "5px", cursor: "pointer" }}>
                    Share
                </button>
            </div>

            {/* Nav Tabs */}
            <ul className="nav nav-tabs" style={{ marginBottom: "15px" }}>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === "overview" ? "active" : ""}`}
                        onClick={() => setActiveTab("overview")}
                    >
                        Overview
                    </button>
                </li>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === "itinerary" ? "active" : ""}`}
                        onClick={() => setActiveTab("itinerary")}
                    >
                        Itinerary Planner
                    </button>
                </li>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === "reviews" ? "active" : ""}`}
                        onClick={() => setActiveTab("reviews")}
                    >
                        Reviews ({reviews.length})
                    </button>
                </li>
            </ul>

            {/* Tab Content */}
            <div className="tab-content">
                {activeTab === "overview" && (
                    <div className="tab-pane active">
                        <h4>About {destination.destinationName}</h4>
                        <p>{destination.description || destination.destinationSummary}</p>

                        <h4>History</h4>
                        <p>{destination.history}</p>

                        <h4>Culture</h4>
                        <p>{destination.culture}</p>

                        <h4>Top Attractions</h4>
                        <ul>
                            {destination.touristAttractions.map((place, i) => (
                                <li key={i}>{place}</li>
                            ))}
                        </ul>

                        <h4 className="mt-4" style={{ backgroundColor: "#007bff", color: "white", padding: "5px 10px", borderRadius: "5px" }}>
                            Recommended Stays
                        </h4>
                        {destination.recommendedHotels.map((hotel, i) => (
                            <div key={i} className="mb-2" style={{ borderBottom: "1px solid #ddd", paddingBottom: "10px" }}>
                                <strong>{hotel.hotelName}</strong> <br />
                                <span style={{ color: "#555" }}>{hotel.type || "Luxury"}</span>
                                <span style={{ float: "right", color: "#007bff", fontWeight: "bold" }}>${hotel.price}+ </span>
                                <div style={{ color: "#f39c12" }}>
                                    {Array(Math.round(hotel.rating))
                                        .fill()
                                        .map((_, i) => (
                                            <FaStar key={i} />
                                        ))}
                                </div>
                            </div>
                        ))}

                        <h4 className="mt-4" style={{ backgroundColor: "#007bff", color: "white", padding: "5px 10px", borderRadius: "5px" }}>
                            Dining Options
                        </h4>
                        {destination.recommendedRestaurants.map((res, i) => (
                            <div key={i} className="mb-2" style={{ borderBottom: "1px solid #ddd", paddingBottom: "10px" }}>
                                <strong>{res.restaurantName}</strong> <br />
                                <span style={{ color: "#555" }}>{res.cuisine}</span>
                                <span style={{ float: "right", color: "#007bff", fontWeight: "bold" }}>
                                    {res.priceRange || "$$$"}
                                </span>
                                <div style={{ color: "#f39c12" }}>
                                    {Array(Math.round(res.rating))
                                        .fill()
                                        .map((_, i) => (
                                            <FaStar key={i} />
                                        ))}
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === "itinerary" && (
                    <div className="tab-pane active">
                        <h4>Itinerary Planner</h4>
                        {loadingItinerary ? (
                            <p>Loading itineraries...</p>
                        ) : itineraries.length === 0 ? (
                            <div className="text-center">
                                <p>No itineraries found for this destination.</p>
                            </div>
                        ) : (
                            <ItineraryList itineraries={itineraries} />
                        )}

                        {/* Always show Create Itinerary button */}
                        <div className="text-center mt-3">
                        <button
                            className="btn btn-primary"
                            onClick={() => {
                                if (!isAuthenticated) {
                                    alert("Please log in to create an itinerary.");
                                    setTimeout(() => navigate("/login"), 100);
                                } else {
                                    navigate(`/create-itinerary/${destination.destinationId}`);
                                }
                            }}
                        >
                            Create Itinerary
                        </button>
                        </div>
                    </div>
                )}

                {activeTab === "reviews" && (
                    <div className="tab-pane active">
                        <h4>User Reviews</h4>
                        {loadingReviews ? (
                            <p>Loading reviews...</p>
                        ) : reviewsError ? (
                            <p style={{ color: "red" }}>{reviewsError}</p>
                        ) : reviews.length === 0 ? (
                            <p>No reviews yet.</p>
                        ) : (
                            reviews.map((rev, i) => (
                                <div key={i} className="border rounded p-2 mb-2">
                                    <strong>{rev.user || "Anonymous"}</strong> - ⭐ {rev.rating}
                                    <p>{rev.comment}</p>
                                </div>
                            ))
                        )}
                        <ReviewForm
                            type="destination-guide"
                            id={destination.destinationId}
                            token={token}
                            onReviewAdded={() => {
                                fetchReviews();
                            }}
                        />
                    </div>
                )}
            </div>
        </div>

    );

}