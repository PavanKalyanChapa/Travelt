import React, { useState, useEffect } from "react";

import { useParams, useNavigate } from "react-router-dom";

import axios from "axios";

import PreferenceForm from "./PreferenceForm";




const CreateItinerary = () => {
    const { destinationId } = useParams();
    const navigate = useNavigate();
    const [destination, setDestination] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (!token) {
            alert("Please log in to create an itinerary.");
            navigate("/login");
            return;
        }
        // Set authorization header for axios
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }, [navigate]);

    const getBackgroundImage = (destinationName) => {
        if (destinationName && destinationName.toLowerCase().includes('bali')) {
            return '/BAL.jpg';
        }
        // Add more conditions for other destinations as images are added
        return null;
    };

    const [itinerary, setItinerary] = useState({

        id: "",

        destinationId: destinationId || "",

        destination: "",

        duration: "",

        activities: [],

        lodging: "",

        dining: "",

    });

    const [preferences, setPreferences] = useState({

        budget: "medium",

        activityLevel: "moderate",

        cuisinePreferences: [],

    });

    const [recommendations, setRecommendations] = useState({

        lodging: [],

        dining: [],

        activities: [],

    });

    useEffect(() => {

        const fetchDestination = async () => {

            try {

                const response = await axios.get("http://localhost:5000/destinations");

                const dest = response.data.find(d => d.destinationId === Number(destinationId));

                if (dest) {

                    setDestination(dest);

                    setItinerary(prev => ({

                        ...prev,

                        destination: dest.destinationName,

                        destinationId: dest.destinationId

                    }));

                    // Set recommendations based on destination data
                    setRecommendations({
                        lodging: dest.recommendedHotels || [],
                        dining: dest.recommendedRestaurants || [],
                        activities: dest.touristAttractions || []
                    });

                } else {

                    setError("Destination not found. The location may not be available.");

                }

            } catch (error) {

                console.error("Error fetching destination:", error);

            }

        };

        if (destinationId) {

            fetchDestination();

        }

    }, [destinationId]);

    const handlePreferenceChange = (e) => {

        const { name, value } = e.target;

        setPreferences({ ...preferences, [name]: value });

    };

    const handleCuisineChange = (cuisine) => {

        setPreferences(prev => ({

            ...prev,

            cuisinePreferences: prev.cuisinePreferences.includes(cuisine)

                ? prev.cuisinePreferences.filter(c => c !== cuisine)

                : [...prev.cuisinePreferences, cuisine]

        }));

    };

    const handleChange = (e) => {

        const { name, value } = e.target;

        setItinerary({ ...itinerary, [name]: value });

    };




    const handleSubmit = async (e) => {

        e.preventDefault();




        // Convert activities from comma-separated string → array

        const formattedItinerary = {

            ...itinerary,

            id: Number(itinerary.id),

            destinationId: Number(itinerary.destinationId),

            activities: itinerary.activities.split(",").map((a) => a.trim()),

        };




        try {
            await axios.post("http://localhost:5000/trip-itineraries", formattedItinerary);
            alert("Itinerary created successfully!");
            setItinerary({
                id: "",
                destinationId: "",
                destination: "",
                duration: "",
                activities: "",
                lodging: "",
                dining: "",
            });
            // Redirect to destination details itinerary tab after creation
            window.location.href = `/destinations/${destinationId}`;
        } catch (error) {
            console.error("Error creating itinerary:", error);
            if (error.response?.status === 401) {
                alert("Please log in to create an itinerary.");
                navigate("/login");
            } else {
                alert("Failed to create itinerary");
            }
        }

    };




    if (!destination) {
        return <div>Loading destination...</div>;
    }

    const bgImage = getBackgroundImage(destination.destinationName);

    return (
        <div style={{
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "30px",
            fontFamily: "Arial, sans-serif",
            backgroundColor: bgImage ? "transparent" : "#f8f9fa",
            backgroundImage: bgImage ? `url(${bgImage})` : "none",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            minHeight: "100vh"
        }}>
            <div style={{
                backgroundColor: "rgba(255, 255, 255, 0.1)",
                backdropFilter: "blur(10px)",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                borderRadius: "15px",
                padding: "30px",
                boxShadow: "0 4px 20px rgba(0,0,0,0.1)"
            }}>
                <h2 style={{
                    color: "#2c3e50",
                    textAlign: "center",
                    marginBottom: "30px",
                    fontSize: "2.5em",
                    fontWeight: "300",
                    textShadow: "0 0 10px rgba(255,255,255,0.8)"
                }}>
                    Create Your Perfect Itinerary for {destination.destinationName}
                </h2>

                <div style={{ display: "flex", gap: "40px", flexWrap: "wrap" }}>
                    <div style={{ flex: "1", minWidth: "400px" }}>
                        <div style={{
                            backgroundColor: "rgba(19, 86, 119, 0.1)",
                            borderRadius: "10px",
                            padding: "25px",
                            marginBottom: "25px"
                        }}>
                            <h3 style={{
                                color: "#135677",
                                marginBottom: "20px",
                                fontSize: "1.4em",
                                borderBottom: "2px solid #135677",
                                paddingBottom: "10px"
                            }}>
                                Step 1: Set Your Preferences
                            </h3>
                            <PreferenceForm
                                preferences={preferences}
                                onPreferenceChange={handlePreferenceChange}
                                cuisineOptions={["Italian", "Chinese", "Mexican", "Indian", "French", "Japanese"]}
                                onCuisineChange={handleCuisineChange}
                            />
                        </div>

                        <div style={{
                            backgroundColor: "rgba(19, 86, 119, 0.1)",
                            borderRadius: "10px",
                            padding: "25px"
                        }}>
                            <h3 style={{
                                color: "#135677",
                                marginBottom: "20px",
                                fontSize: "1.4em",
                                borderBottom: "2px solid #135677",
                                paddingBottom: "10px"
                            }}>
                                Step 2: Itinerary Details
                            </h3>
                            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
                                <div>
                                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#555" }}>
                                        Itinerary ID *
                                    </label>
                                    <input
                                        type="number"
                                        name="id"
                                        placeholder="Enter unique itinerary ID"
                                        value={itinerary.id}
                                        onChange={handleChange}
                                        required
                                        style={{
                                            width: "100%",
                                            padding: "12px",
                                            border: "2px solid #ddd",
                                            borderRadius: "8px",
                                            fontSize: "16px",
                                            transition: "border-color 0.3s"
                                        }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#555" }}>
                                        Duration
                                    </label>
                                    <input
                                        type="text"
                                        name="duration"
                                        placeholder="e.g., 7 days"
                                        value={itinerary.duration}
                                        onChange={handleChange}
                                        style={{
                                            width: "100%",
                                            padding: "12px",
                                            border: "2px solid #ddd",
                                            borderRadius: "8px",
                                            fontSize: "16px",
                                            transition: "border-color 0.3s"
                                        }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#555" }}>
                                        Activities
                                    </label>
                                    <textarea
                                        name="activities"
                                        placeholder="Enter activities separated by commas"
                                        value={itinerary.activities}
                                        onChange={handleChange}
                                        rows="4"
                                        style={{
                                            width: "100%",
                                            padding: "12px",
                                            border: "2px solid #ddd",
                                            borderRadius: "8px",
                                            fontSize: "16px",
                                            resize: "vertical",
                                            transition: "border-color 0.3s"
                                        }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#555" }}>
                                        Lodging
                                    </label>
                                    <input
                                        type="text"
                                        name="lodging"
                                        placeholder="Preferred accommodation type"
                                        value={itinerary.lodging}
                                        onChange={handleChange}
                                        style={{
                                            width: "100%",
                                            padding: "12px",
                                            border: "2px solid #ddd",
                                            borderRadius: "8px",
                                            fontSize: "16px",
                                            transition: "border-color 0.3s"
                                        }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold", color: "#555" }}>
                                        Dining
                                    </label>
                                    <input
                                        type="text"
                                        name="dining"
                                        placeholder="Preferred dining options"
                                        value={itinerary.dining}
                                        onChange={handleChange}
                                        style={{
                                            width: "100%",
                                            padding: "12px",
                                            border: "2px solid #ddd",
                                            borderRadius: "8px",
                                            fontSize: "16px",
                                            transition: "border-color 0.3s"
                                        }}
                                    />
                                </div>

                                <button
                                    type="submit"
                                    style={{
                                        backgroundColor: "#3498db",
                                        color: "white",
                                        padding: "15px 30px",
                                        border: "none",
                                        borderRadius: "8px",
                                        fontSize: "18px",
                                        fontWeight: "bold",
                                        cursor: "pointer",
                                        transition: "background-color 0.3s",
                                        marginTop: "20px"
                                    }}
                                    onMouseOver={(e) => e.target.style.backgroundColor = "#2980b9"}
                                    onMouseOut={(e) => e.target.style.backgroundColor = "#3498db"}
                                >
                                    Create My Itinerary
                                </button>
                            </form>
                        </div>
                    </div>

                    <div style={{ flex: "1", minWidth: "400px" }}>
                        <div style={{
                            backgroundColor: "rgba(248, 131, 121, 0.1)",
                            borderRadius: "10px",
                            padding: "25px",
                            height: "fit-content"
                        }}>
                            <h3 style={{
                                color: "#F88379",
                                marginBottom: "20px",
                                fontSize: "1.4em",
                                borderBottom: "2px solid #F88379",
                                paddingBottom: "10px"
                            }}>
                                🌟 Recommendations
                            </h3>

                            <div style={{ marginBottom: "25px" }}>
                                <h4 style={{ color: "#2c3e50", marginBottom: "15px" }}>🏨 Lodging Options</h4>
                                {recommendations.lodging.map((hotel, index) => (
                                    <div key={index} style={{
                                        backgroundColor: "white",
                                        border: "1px solid #e8e8e8",
                                        borderRadius: "8px",
                                        padding: "15px",
                                        margin: "8px 0",
                                        boxShadow: "0 2px 4px rgba(0,0,0,0.05)"
                                    }}>
                                        <strong style={{ color: "#2c3e50" }}>{hotel.hotelName}</strong>
                                        <br />
                                        <span style={{ color: "#27ae60", fontWeight: "bold" }}>${hotel.price}+ per night</span>
                                        <div style={{ display: "flex", marginTop: "5px" }}>
                                            {Array(Math.floor(hotel.rating)).fill().map((_, i) => (
                                                <span key={i} style={{ color: "#f39c12" }}>★</span>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div style={{ marginBottom: "25px" }}>
                                <h4 style={{ color: "#2c3e50", marginBottom: "15px" }}>🍽️ Dining Options</h4>
                                {recommendations.dining.map((restaurant, index) => (
                                    <div key={index} style={{
                                        backgroundColor: "white",
                                        border: "1px solid #e8e8e8",
                                        borderRadius: "8px",
                                        padding: "15px",
                                        margin: "8px 0",
                                        boxShadow: "0 2px 4px rgba(0,0,0,0.05)"
                                    }}>
                                        <strong style={{ color: "#2c3e50" }}>{restaurant.restaurantName}</strong>
                                        <br />
                                        <span style={{ color: "#e67e22" }}>{restaurant.cuisine} Cuisine</span>
                                        <div style={{ display: "flex", marginTop: "5px" }}>
                                            {Array(Math.floor(restaurant.rating)).fill().map((_, i) => (
                                                <span key={i} style={{ color: "#f39c12" }}>★</span>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div>
                                <h4 style={{ color: "#2c3e50", marginBottom: "15px" }}>🎯 Popular Activities</h4>
                                {recommendations.activities.map((activity, index) => (
                                    <div key={index} style={{
                                        backgroundColor: "white",
                                        border: "1px solid #e8e8e8",
                                        borderRadius: "8px",
                                        padding: "15px",
                                        margin: "8px 0",
                                        boxShadow: "0 2px 4px rgba(0,0,0,0.05)"
                                    }}>
                                        <strong style={{ color: "#2c3e50" }}>🎭 {activity}</strong>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CreateItinerary;
