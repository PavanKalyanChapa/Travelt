import React from "react";
import { useState } from 'react';
import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// code
const url = "http://localhost:5000/api/auth/register";
const RegisterUser = () => {

    // const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        phoneNumber: "",
        password: "",
        confirmPassword: ""

    })

    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    const [formValid, setFormValid] = useState({
        name: false,
        email: false,
        phoneNumber: false,
        password: false,
        confirmPassword: false,
        submitButton: false
    })

    const [fieldError, setfieldError] = useState({
        name: "",
        email: "",
        password: "",
        phoneNumber: "",
    });

    const handleSubmit = (event) => {
        event.preventDefault()

        axios.post(url, formData).then((resposne) => {
            setSuccessMessage(resposne.data.Message);
            setErrorMessage("");
            //navigate("/login");

        }).catch(err => {
            if (err.status == 409) {
                setErrorMessage(err.response.data.error);
                setSuccessMessage("");
            }
            else setErrorMessage("Error while registration");
        })

    }

    const validateField = (fieldName, fieldValue) => {
        const newFormValid = { ...formValid };
        const newFieldError = { ...fieldError }

        switch (fieldName) {
            case "email":
                {
                    const regex = /^$|^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
                    if (fieldValue === "") {
                        newFieldError.email = "email id should not empty";
                        newFormValid.email = false;
                    } else if (!regex.test(fieldValue)) {
                        newFieldError.email = "Invalid Email !!";
                        newFormValid.email = false;
                    } else {
                        newFieldError.email = "";
                        newFormValid.email = true;
                    }
                    break;
                }
            case "phoneNumber": {
                const regex = /^[6-9][0-9]{9}/
                if (fieldValue === "") {
                    newFieldError.phoneNumber = "Phone Number should not Empty";
                    newFormValid.phoneNumber = false;
                } else if (!regex.test(fieldValue)) {
                    newFieldError.phoneNumber = "Invalid Phone !!";
                    newFormValid.phoneNumber = false;
                } else {
                    newFieldError.phoneNumber = "";
                    newFormValid.phoneNumber = true;
                }
                break;

            }

            case "password": {

                const regex = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,20}$/;
                if (fieldValue === "") {
                    newFieldError.password = "Password should not Empty";
                    newFormValid.password = false;
                } else if (!regex.test(fieldValue)) {
                    newFieldError.password = "Password doesn't meet the Criteria !! Enter Strong Password";
                    newFormValid.password = false;
                } else {
                    newFieldError.password = "";
                    newFormValid.password = true;
                }

                break;
            }

            case "confirmPassword": {
                if (fieldValue === "") {
                    newFieldError.confirmPassword = "confirmPassword should not Empty";
                    newFormValid.confirmPassword = false;
                } else if (fieldValue !== formData.password) {
                    newFieldError.confirmPassword = "password and confirm password should be same";
                    newFormValid.confirmPassword = false;
                } else {
                    newFieldError.confirmPassword = "";
                    newFormValid.confirmPassword = true;
                }

                break;
            }

            default:
                break;
        }

        newFormValid.submitButton = newFormValid.email && newFormValid.password && newFormValid.phoneNumber && newFormValid.confirmPassword;
        console.log("newFormValid.submitButton : ", newFormValid.submitButton);

        setFormValid(newFormValid);
        setfieldError(newFieldError);

    }

    const handleChange = (event) => {
        const fieldName = event.target.name;
        const fieldValue = event.target.value;

        setFormData({
            ...formData,
            [fieldName]: fieldValue
        })

        validateField(fieldName, fieldValue);
    }

    return (

        // <div className="container d-flex justify-content-center pt-4 mt-5">
        //     <div className="row card shadow" style={{ width: "40rem" }}>
        //         <h4 className="card-header bg-info text-center">Register User</h4>

        //         <form>

        //             <div className="form-group">
        //                 <label htmlFor="name" className="form-label">Name</label>
        //                 <input
        //                     type="text"
        //                     name="name"
        //                     id="name"
        //                     className="form-control"
        //                     value={formData.name}
        //                     onChange={handleChange}
        //                     placeholder="Enter Name Here"
        //                 />
        //                 {fieldError.name && <span className="form-text text-danger">{fieldError.name}</span>}
        //             </div>

        //             <div className="form-group">
        //                 <label htmlFor="email" className="form-label">Email</label>
        //                 <input
        //                     type="text"
        //                     name="email"
        //                     id="email"
        //                     className="form-control"
        //                     value={formData.email}
        //                     onChange={handleChange}
        //                     placeholder="Enter email Here"
        //                 />
        //                 {fieldError.email && <span className="form-text text-danger">{fieldError.email}</span>}
        //             </div>

        //             <div className="form-group">
        //                 <label htmlFor="phoneNumber" className="form-label">Phone</label>
        //                 <input
        //                     type="number"
        //                     name="phoneNumber"
        //                     id="phoneNumber"
        //                     className="form-control"
        //                     value={formData.phoneNumber}
        //                     onChange={handleChange}
        //                     placeholder="Enter phoneNumber Here"
        //                 />
        //                 {fieldError.phoneNumber && <span className="form-text text-danger">{fieldError.phoneNumber}</span>}
        //             </div>

        //             <div className="form-group">
        //                 <label htmlFor="password"  className="form-label">password</label>
        //                 <input
        //                     type="password"
        //                     name="password"
        //                     id="password"
        //                     className="form-control"
        //                     value={formData.password}
        //                     onChange={handleChange}
        //                     placeholder="Enter password Here"
        //                 />
        //                 {fieldError.password && <span className="form-text text-danger">{fieldError.password}</span>}
        //             </div>

        //             <div className="form-group">
        //                 <label htmlFor="confirmPassword"  className="form-label">confirm Password</label>
        //                 <input
        //                     type="password"
        //                     name="confirmPassword"
        //                     id="confirmPassword"
        //                     className="form-control"
        //                     value={formData.confirmPassword}
        //                     onChange={handleChange}
        //                     placeholder="Enter confirm password Here"
        //                 />
        //                 {fieldError.confirmPassword && <span className="form-text text-danger">{fieldError.confirmPassword}</span>}
        //             </div>


        //             <div className="form-group pt-3 md-6">
        //                 <button className="form-control btn btn-primary"
        //                     onClick={handleSubmit}
        //                     disabled={!formValid.submitButton} > Register </button>
        //                 {successMessage && <span className="text-success"> {successMessage}</span>}
        //                 {errorMessage && <span className="text-danger"> {errorMessage}</span>}
        //             </div>

        //         </form>
        //     </div>
        // </div>

        <div className="d-flex justify-content-center align-items-center bg-light pt-4">

            <div className="card shadow p-4" style={{ width: "400px", borderRadius: "12px" }}>

                <h3 className="text-center fw-bold mb-2">Join <span style={{ color: "rgb(248, 131, 121)" }}>TravelTroue</span></h3>

                <p className="text-muted text-center mb-4">

                    Create your account to get started

                </p>

                <form onSubmit={handleSubmit}>

                    {/* Name */}

                    <div className="mb-2 text-start">

                        <label className="form-label fw-semibold">Name</label>

                        <input

                            type="text"

                            className="form-control"

                            name="name"

                            placeholder="Enter your name"

                            value={formData.name}

                            onChange={handleChange}

                            required

                        />
                        {fieldError.name && <span className="form-text text-danger">{fieldError.name}</span>}
                    </div>

                    {/* Email */}

                    <div className="mb-3 text-start">

                        <label className="form-label fw-semibold">Email</label>

                        <input

                            type="email"

                            className="form-control"

                            name="email"

                            placeholder="Enter your email"

                            value={formData.email}

                            onChange={handleChange}

                            required

                        />
                        {fieldError.email && <span className="form-text text-danger">{fieldError.email}</span>}
                    </div>

                    {/* Phone */}

                    <div className="mb-3 text-start">

                        <label className="form-label fw-semibold">Phone Number</label>

                        <input

                            type="number"

                            className="form-control"

                            name="phoneNumber"

                            placeholder="Enter your phone number"

                            value={formData.phoneNumber}

                            onChange={handleChange}

                            required

                        />
                        {fieldError.phoneNumber && <span className="form-text text-danger">{fieldError.phoneNumber}</span>}
                    </div>

                    {/* Password */}

                    <div className="mb-3 text-start">

                        <label className="form-label fw-semibold">Password</label>

                        <input

                            type="password"

                            className="form-control"

                            name="password"

                            placeholder="Enter your password"

                            value={formData.password}

                            onChange={handleChange}

                            required

                        />
                        {fieldError.password && <span className="form-text text-danger">{fieldError.password}</span>}
                    </div>

                    {/* Confirm Password */}

                    <div className="mb-3 text-start">

                        <label className="form-label fw-semibold">Confirm Password</label>

                        <input

                            type="password"

                            className="form-control"

                            name="confirmPassword"

                            placeholder="Re-enter your password"

                            value={formData.confirmPassword}

                            onChange={handleChange}

                            required

                        />
                        {fieldError.confirmPassword && <span className="form-text text-danger">{fieldError.confirmPassword}</span>}
                    </div>

                    {/* Submit Button */}

                    <button type="submit" className="btn btn-success w-100 fw-semibold" style={{ backgroundColor: "rgb(248, 131, 121)" }} disabled={!formValid.submitButton}>

                        Create Account

                    </button>
                    {successMessage && <span className="text-success"> {successMessage}</span>}
                    {errorMessage && <span className="text-danger"> {errorMessage}</span>}
                </form>

                <p className="text-center mt-3 text-muted">

                    Already have an account?{" "}

                    <a href="/login" className="text-success fw-semibold text-decoration-none">

                        Sign in here

                    </a>

                </p>

            </div>

        </div>
    )

}
export default RegisterUser;



