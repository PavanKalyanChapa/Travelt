const express = require('express')
const router = express.Router()
const service = require('../service/service')

class User {
    constructor(userObj) {
        this.name = userObj.name,
            this.email = userObj.email,
            this.password = userObj.password,
            this.phoneNumber = userObj.phoneNumber


    }
}

// Favorites Management
// Add Favorite
router.post('/favorites', service.authenticateToken, async (req, res, next) => {
    try {
        const { type, id } = req.body;
        if (!type || !id) {
            return res.status(400).json({ error: "Invalid request body" });
        }
        const added = await service.addFavorite({ type, id });
        if (added) {
            res.status(200).json({ message: `${type} added to favorites` });
        } else {
            res.status(400).json({ error: "Failed to add favorite" });
        }
    } catch (error) {
        next(error);
    }
});

// View Favorites
router.get('/favorites', service.authenticateToken, async (req, res, next) => {
    try {
        const favorites = await service.getFavorites();
        res.status(200).json({ favorites });
    } catch (error) {
        next(error);
    }
});

// Remove Favorite
router.delete('/favorites/:id', service.authenticateToken, async (req, res, next) => {
    try {
        const id = req.params.id;
        const removed = await service.removeFavorite(id);
        if (removed) {
            res.status(200).json({ message: "Favorite removed successfully" });
        } else {
            res.status(404).json({ error: "Favorite not found" });
        }
    } catch (error) {
        next(error);
    }
});

router.post('/trip-itineraries', service.authenticateToken, async (req, res, next) => {
    try {
        const itinerary = req.body;
        const postt = await service.addItinerary(itinerary);
        if (postt) {
            res.status(200).json({
                "message": "Trip itinerary created successfully"
            });
        }
        else {
            res.status(400).json({
                "error": "Invalid request body"
            })
        }
    } catch (error) {
        next(error);
    }
});

router.get('/trip-itineraries/:id', async (req, res, next) => {
    try {
        const itiId = Number(req.params.id);
        const itineraries = await service.findItinerary(itiId);
        if (itineraries) {
            res.status(200).json({ itineraries });
        } else {
            res.status(404).json({
                "error": "Trip itinerary not found"
            })
        }
    } catch (error) {
        next(error)
    }
})

router.get('/destinations', async (req, res, next) => {
    try {
        const destinations = await service.findDestinatios();
        res.json(destinations)
    } catch (error) {
        next(error)
    }
})

router.get('/destination/:Id', async (req, res, next) => {
    try {
        const destId = req.params.Id
        const destination = await service.findDestinationsById(destId);
        res.json(destination)
    } catch (error) {
        next(error)
    }
})

// Add review for destination or itinerary
router.post('/reviews', service.authenticateToken, async (req, res, next) => {
    try {
        const { type, id, user, rating, comment } = req.body;
        if (!type || !id || !user || !rating) {
            return res.status(400).json({ error: "Missing required fields" });
        }
        const added = await service.addReview({ type, id, user, rating, comment });
        if (added) {
            res.status(200).json({ message: "Review added successfully" });
        } else {
            res.status(400).json({ error: "Failed to add review" });
        }
    } catch (error) {
        next(error);
    }
});

// Get reviews filtered by location, activity, or type and id
router.get('/reviews', async (req, res, next) => {
    try {
        const { location, activity, type, id } = req.query;
        const filter = { location, activity };

        if (type && id) {
            filter.type = type;
            filter.id = Number(id);
        }

        const reviews = await service.getReviews(filter);
        res.status(200).json({ reviews });
    } catch (error) {
        next(error);
    }
});

router.post('/register', async (req, res, next) => {
    const newUser = new User(req.body);
    console.log(req.body);
    if (await service.existingUser(newUser)) {
        console.log("User Already Exists")
        return res.status(409).json({ error: "User Already exists !! please Login to Continue" });
    } else {
        const userAck = service.addUser(newUser);
        if (userAck) {
            return res.status(200).json({ "Message": "User Registered Successfully !!!! Login to Proceed" });
        } else {
            return res.status(400).json({ error: "Unable to add the user" });
        }
    }
})

router.post("/login", async (req, res) => {

    try {

        const { email, password } = req.body;
        console.log(req.body);

        const response = await service.loginUser(email, password);

        res.json(response);

    } catch (error) {

        res.status(401).json({ error: error.message });

    }



});


router.get("/profile", service.authenticateToken, (req, res) => {
    res.json({ "message": "Welcome to your account" });
});

module.exports = router


