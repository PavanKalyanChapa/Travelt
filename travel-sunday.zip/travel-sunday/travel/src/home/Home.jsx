import React from "react";

import { useQuery } from "@tanstack/react-query";

import { useNavigate } from "react-router-dom";

import { useEffect, useState } from 'react';

import axios from 'axios';

import { FaFacebook, FaInstagram, FaTwitter, FaYoutube } from "react-icons/fa";

import DestinationCard from '../components/Destination/DestinationCard';
import HomeReviews from "../components/HomeReviews";



export default function Home() {

    const navigate = useNavigate();

    const [destinations, setDestinations] = useState([]);

    const fetchDestinations = async () => {

        try {

            const response = await axios.get("http://localhost:5000/destinations");

            setDestinations(Array.isArray(response.data) ? response.data : []);

        } catch (error) {

            console.log(error);

        }

    }

    useEffect(() => {

        fetchDestinations()

    }, [])




    const sampleReviews = [

        {

            id: "1",

            rating: 5,

            comment:

                "Traveltrove's Bali guide was incredibly detailed and helpful. The itinerary suggestions were spot-on and made our trip unforgettable!",

            userName: "Alex Johnson",

            userAvatar:

                "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",

            destinationName: "Bali, Indonesia",

        },

        {

            id: "2",

            rating: 4,

            comment:

                "The travel group feature helped me find amazing travel companions for my Japan trip. Made lifelong friends through this platform!",

            userName: "Sarah Chen",

            destinationName: "Tokyo, Japan",

        },

        {

            id: "3",

            rating: 5,

            comment:

                "The itinerary builder is genius! Saved me hours of planning and the recommendations were perfect for my adventure style.",

            userName: "Marcus Rodriguez",

            destinationName: "Iceland",

        },

    ];




    const [searchTerm, setSearchTerm] = useState("")

    const [results, setResults] = useState([])

    const [isSearch, setIsSearch] = useState(false)




    const handleSearch = (e) => {

        const term = e.target.value;

        setSearchTerm(term);

        const searchWords = term.split(' ');




        if (term == "") {

            setResults([]);

            setIsSearch(false);

            return

        }

        setIsSearch(true);

        const filterGuides = destinations.filter((guide) => {

            return searchWords.some((word) => {

                return guide.title.toLowerCase().includes(word.toLowerCase()) || guide.destinationSummary.toLowerCase().includes(word.toLowerCase());

            })

        });

        // Sort by relevance (number of matching words) and then by rating
        const sortedResults = filterGuides.sort((a, b) => {
            const aMatches = searchWords.filter(word =>
                a.title.toLowerCase().includes(word.toLowerCase()) || a.destinationSummary.toLowerCase().includes(word.toLowerCase())
            ).length;
            const bMatches = searchWords.filter(word =>
                b.title.toLowerCase().includes(word.toLowerCase()) || b.destinationSummary.toLowerCase().includes(word.toLowerCase())
            ).length;
            if (bMatches !== aMatches) {
                return bMatches - aMatches; // More matches first
            }
            return b.rating - a.rating; // Higher rating first
        });

        setResults(sortedResults);

    }

    const clearSearch = () => {

        setSearchTerm("");

        setResults([]);

        setIsSearch(false);

        display = []

        return;

    }




    let display = searchTerm.length > 0 ? results : destinations;

    return (

        <div>

            <section

                className="d-flex align-items-center justify-content-center text-center text-white"

                style={{

                    height: "70vh",

                    backgroundImage: `linear-gradient(rgba(15, 76, 117, 0.5), rgba(255, 107, 107, 0.5)), url('./bg.jpeg')`,

                    backgroundSize: "cover",

                    backgroundPosition: "center",

                }}

            >

                <div className="container">

                    <h1 className="display-3 fw-bold mb-4">

                        Discover Your Next{" "}

                        <span style={{ color: "#FED429" }}>Adventure</span>

                    </h1>

                    <p className="lead mb-5">

                        Explore destination guides, create custom itineraries, and connect

                        with fellow travelers

                    </p>




                    <div className="mx-auto" style={{ maxWidth: "600px" }}>

                        <div className="input-group">

                            <input

                                type="text"

                                className="form-control form-control-lg"

                                placeholder="Search destinations by name, description"

                                value={searchTerm}

                                onChange={handleSearch} />

                            {

                                searchTerm && (<button className="btn btn-outline-primary" style={{ backgroundColor: "#135677", color: "white" }} onClick={() => { clearSearch() }}>Clear</button>)

                            }

                        </div>

                    </div>

                </div>

            </section>




            {/* Featured Destinations */}

            <section className="py-5 bg-light">

                <div className="container">

                    <div className="text-center mb-5">

                        {searchTerm ? (<><h2 className="fw-bold mb-3">Search Results for "{searchTerm}"</h2></>) : (

                            <><h2 className="fw-bold mb-3">Featured Destinations</h2>

                                <p className="text-muted">Discover our most popular destination guides</p></>

                        )}




                    </div>




                    {isSearch && results.length == 0 && searchTerm && (

                        <div className="text-center py-4">

                            <div className="alert alert-info">

                                No destinations found matching your search. Try different key words

                            </div>

                        </div>

                    )}









                    <div className="container my-5">

                        <div className="row d-flex " style={{ justifyContent: "center", gap: "4%", margin: "auto" }}>

                            {display.map((dest) => (

                                <div className="col" key={dest.id}>

                                    <DestinationCard guide={dest} />

                                </div>

                            ))}

                        </div>

                    </div>




                    <div className="text-center mt-5">

                        <button

                            className="btn btn-primary btn-lg"

                            onClick={() => navigate("/destinations")} style={{ backgroundColor: "#F88379", border: "none" }}>

                            View All Destinations

                        </button>

                    </div>

                </div>

            </section>




            {/* Itinerary Builder */}

            <section className="py-5">

                <div className="container text-center">

                    <h2 className="fw-bold mb-3">Create Your Perfect Itinerary</h2>

                    <p className="text-muted mb-5">

                        Plan your dream trip with our intuitive itinerary builder

                    </p>




                    {/* <ItineraryBuilder /> */}

                </div>

            </section>




            {/* Travel Groups */}

            <section className="py-5">

                <div className="container text-center">

                    <h2 className="fw-bold mb-3">Join Travel Groups</h2>

                    <p className="text-muted mb-5">

                        Connect with fellow travelers and plan group adventures

                    </p>





                    <div className="d-flex flex-column flex-sm-row justify-content-center gap-3 mt-5">

                        <button className="btn btn-secondary btn-lg" style={{ color: "black", backgroundColor: "#FED429", border: "none" }}>Create New Group</button>

                        <button

                            className="btn btn-primary btn-lg"

                            onClick={() => navigate("/groups")} style={{ backgroundColor: "#135677", border: "none" }}>

                            Browse All Groups

                        </button>

                    </div>

                </div>

            </section>




            {/* Reviews */}

            <section className="py-5 bg-light">

                <div className="container text-center">



                    <div className="row g-4">
                        {/* Replaced sampleReviews with HomeReviews component */}
                        <HomeReviews />
                    </div>

                </div>

            </section>




            {/* Footer */}

            <footer

                className="text-white py-5"

                style={{ backgroundColor: "#135677" }}

            >

                <div className="container">

                    <div className="row">

                        <div className="col-md-3 mb-4">

                            <div className="d-flex align-items-center mb-3">

                                <span style={{ fontSize: "1.5rem" }}>🧭</span>

                                <span className="h5 ms-2 mb-0">Traveltrove</span>

                            </div>

                            <p>

                                Discover amazing destinations, create perfect itineraries, and connect with fellow travelers worldwide.

                            </p>

                            {/* Social Icons */}

                            <div className="d-flex gap-3 mt-3">

                                <a href="https://facebook.com" target="_blank" rel="noreferrer" className="text-white fs-4" style={{ textDecoration: "none" }}>

                                    <FaFacebook />

                                </a>

                                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="text-white fs-4" style={{ textDecoration: "none" }}>

                                    <FaInstagram />

                                </a>

                                <a href="https://twitter.com" target="_blank" rel="noreferrer" className="text-white fs-4" style={{ textDecoration: "none" }}>

                                    <FaTwitter />

                                </a>

                                <a href="https://youtube.com" target="_blank" rel="noreferrer" className="text-white fs-4" style={{ textDecoration: "none" }}>

                                    <FaYoutube />

                                </a>

                            </div>

                        </div>

                        <div className="col-md-3 mt-2 mb-4">

                            <h5>Destinations</h5>

                            <ul className="list-unstyled">

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Asia</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Europe</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Americas</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Africa</a></li>

                            </ul>

                        </div>




                        <div className="col-md-3 mt-2 mb-4">

                            <h5>Features</h5>

                            <ul className="list-unstyled">

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Destination Guides</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Itinerary Builder</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Travel Groups</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Reviews</a></li>

                            </ul>

                        </div>

                        <div className="col-md-3 mt-2 mb-4">

                            <h5>Support</h5>

                            <ul className="list-unstyled">

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Help Center</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Contact Us</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Privacy Policy</a></li>

                                <li><a href="#" className="text-white" style={{ textDecoration: "none" }}>Terms of Service</a></li>

                            </ul>

                        </div>

                    </div>

                    <hr className="border-light" />

                    <div className="text-center">

                        <p className="mb-0">

                            © 2025 Traveltrove. All rights reserved. Made with ❤️ for travelers worldwide.

                        </p>

                    </div>

                </div>

            </footer>

        </div>

    );

}



