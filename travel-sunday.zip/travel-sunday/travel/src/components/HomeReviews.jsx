import React, { useEffect, useState } from "react";
import axios from "axios";
import { FaStar, FaUserCircle } from "react-icons/fa";

const HomeReviews = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReviews = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get("http://localhost:5000/reviews");
        setReviews(response.data.reviews || []);
      } catch (err) {
        setError("Failed to load reviews");
        console.error("Error fetching reviews:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchReviews();
  }, []);

  // Helper to render stars
  const renderStars = (rating) => {
    return (
      <>
        {[...Array(5)].map((_, i) => (
          <FaStar key={i} color={i < rating ? "#ffc107" : "#e4e5e9"} />
        ))}
      </>
    );
  };

  return (
    <div className="tcard" style={{ maxWidth: "900px", margin: "2rem auto", padding: "0 1rem", boxShadow: "none" }}>
      <h2 style={{ textAlign: "center", marginBottom: "0.5rem" }}>What Travelers Say</h2>
      <p style={{ textAlign: "center", color: "#666", marginBottom: "2rem" }}>
        Real reviews from our community of explorers
      </p>

      {loading && <p>Loading reviews...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "center" }}>
        {reviews.map((rev, idx) => (
          <div
            key={idx}
            className="tcard"
            style={{
              padding: "1rem",
              width: "280px",
              display: "flex",
              flexDirection: "column",
              gap: "0.5rem",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontWeight: "bold", fontSize: "1.1rem" }}>
              <FaUserCircle size={24} />
              {rev.user || "Anonymous"}
            </div>
            <div>{renderStars(rev.rating)}</div>
            <div style={{ fontStyle: "italic", color: "#333" }}>"{rev.comment}"</div>
            {/* Placeholder for location and time ago */}
            <div style={{ fontSize: "0.85rem", color: "#999" }}>
              {/* Example: Bali, Indonesia • 2 weeks ago */}
              Location unknown • Date unknown
            </div>
          </div>
        ))}
      </div>

      <div style={{ textAlign: "center", marginTop: "2rem" }}>
        <button
          style={{
            backgroundColor: "#e74c3c",
            color: "white",
            border: "none",
            padding: "10px 20px",
            borderRadius: "5px",
            cursor: "pointer",
            fontWeight: "bold",
          }}
          onClick={() => alert("Feature to share your review coming soon!")}
        >
          Share Your Review
        </button>
      </div>
    </div>
  );
};

export default HomeReviews;
