import React from "react";

const PreferenceForm = ({ preferences, onPreferenceChange, cuisineOptions, onCuisineChange }) => {
  return (
    <div>
      <h3>Preferences</h3>
      <label>
        Budget:
        <select name="budget" value={preferences.budget} onChange={onPreferenceChange}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </label>
      <br />
      <label>
        Activity Level:
        <select name="activityLevel" value={preferences.activityLevel} onChange={onPreferenceChange}>
          <option value="low">Low</option>
          <option value="moderate">Moderate</option>
          <option value="high">High</option>
        </select>
      </label>
      <br />
      <fieldset>
        <legend>Cuisine Preferences:</legend>
        {cuisineOptions.map((cuisine) => (
          <label key={cuisine} style={{ marginRight: "10px" }}>
            <input
              type="checkbox"
              checked={preferences.cuisinePreferences.includes(cuisine)}
              onChange={() => onCuisineChange(cuisine)}
            />
            {cuisine}
          </label>
        ))}
      </fieldset>
    </div>
  );
};

export default PreferenceForm;
