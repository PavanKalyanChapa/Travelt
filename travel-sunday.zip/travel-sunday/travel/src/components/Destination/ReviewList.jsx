import { useState, useEffect } from "react";
import axios from "axios";

export default function ReviewList({ location, activity }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReviews = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = {};
        if (location) params.location = location;
        if (activity) params.activity = activity;

        const response = await axios.get("http://localhost:5000/reviews", { params });
        setReviews(response.data.reviews || []);
      } catch (err) {
        setError("Failed to load reviews");
        console.error("Error fetching reviews:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchReviews();
  }, [location, activity]);

  if (loading) {
    return <p>Loading reviews...</p>;
  }

  if (error) {
    return <p style={{ color: "red" }}>{error}</p>;
  }

  if (reviews.length === 0) {
    return <p>No reviews found.</p>;
  }

  return (
    <div>
      {reviews.map((review, index) => (
        <div key={index} className="border rounded p-3 mb-3">
          <div className="d-flex justify-content-between align-items-start">
            <div>
              <strong>{review.user || "Anonymous"}</strong>
              <div className="text-warning">
                {"⭐".repeat(review.rating)}
              </div>
            </div>
            <small className="text-muted">
              {review.type === "destination-guide" ? "Destination" : "Itinerary"}
            </small>
          </div>
          <p className="mt-2 mb-0">{review.comment}</p>
        </div>
      ))}
    </div>
  );
}
