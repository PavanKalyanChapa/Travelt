const model = require('../model/model')
const bcrypt = require('bcrypt')
const JWT_SECRET = process.env.JWT_SECRET || "supersecretkey"
const jwt = require('jsonwebtoken');

const service = {}


service.existingUser = async (userObj) => {
    const x = await model.existingUser(userObj);
    console.log("x : ", x)
    return x;
}


service.addUser = async (userObj) => {
    const hashedPassword = await bcrypt.hash(userObj.password, 10);
    userObj.password = hashedPassword;
    // console.log(userObj.password);

    if (model.addUser(userObj)) {
        return true;
    }


}


service.loginUser = async (email, password) => {
    const user = await model.findUser(email);
    if (!user) throw new Error("Invalid credentials");
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) throw new Error("Invalid Password");
    const token = jwt.sign({ id: user._id.toString(), email: user.email }, JWT_SECRET, {
        expiresIn: "1h",
    });
    console.log("het is the token ", token);
    return { message: "Login successful", token };

};

// Middleware for token verification

service.authenticateToken = (req, res, next) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (!token) return res.sendStatus(401);
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};


service.findDestinatios = async () => {
    const destinations = await model.findDestinations()
    if (destinations) {
        return destinations
    }
}

service.findDestinationsById = async (destinationId) => {
    const destination = await model.findDestinationById(destinationId);
    if (destination) {
        return destination
    }
}

service.addItinerary = async (itinerary) => {
    const posting = await model.addItinerary(itinerary);
    if (posting) {
        return posting;
    }
}

service.findItinerary = async (id) => {
    const fetch = await model.findItinerary(id);
    if (fetch) {
        return fetch;
    }
}

// Favorites Management
service.addFavorite = async (favorite) => {
    const added = await model.addFavorite(favorite);
    if (added) {
        return added;
    }
}

service.getFavorites = async () => {
    const favorites = await model.getFavorites();
    if (favorites) {
        return favorites;
    }
    return [];
}

service.removeFavorite = async (id) => {
    const removed = await model.removeFavorite(id);
    if (removed) {
        return removed;
    }
}

// Reviews Management
service.addReview = async (review) => {
    const added = await model.addReview(review);
    if (added) {
        return added;
    }
}

service.getReviews = async (filter) => {
    const reviews = await model.getReviews(filter);
    if (reviews) {
        return reviews;
    }
    return [];
}

module.exports = service



