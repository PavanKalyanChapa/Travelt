import { useState } from "react";
import ReviewList from "./ReviewList";

export default function ReviewsPage() {
  const [locationFilter, setLocationFilter] = useState("");
  const [activityFilter, setActivityFilter] = useState("");

  return (
    <div className="container my-4">
      <h2>User Reviews</h2>

      {/* Filters */}
      <div className="row mb-4">
        <div className="col-md-6">
          <label className="form-label">Filter by Location:</label>
          <input
            type="text"
            className="form-control"
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
            placeholder="Enter destination name"
          />
        </div>
        <div className="col-md-6">
          <label className="form-label">Filter by Activity:</label>
          <input
            type="text"
            className="form-control"
            value={activityFilter}
            onChange={(e) => setActivityFilter(e.target.value)}
            placeholder="Enter activity name"
          />
        </div>
      </div>

      {/* Reviews List */}
      <ReviewList location={locationFilter} activity={activityFilter} />
    </div>
  );
}
