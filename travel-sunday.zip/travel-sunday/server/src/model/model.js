const dbModule = require('../utilities/connection')

const model = {}



model.findDestinations = async () => {
    const dbConnect = await dbModule.getDBModel();
    const destinations = await dbConnect.find({}, { _id: 0, __v: 0 });
    if (destinations.length > 0) {
        return destinations
    } else {
        return null
    }
}

model.findDestinationById = async (destinationId) => {
    const dbConnect = await dbModule.getDBModel();
    const destination = await dbConnect.find({ destinationId: destinationId }, { _id: 0, __v: 0 });
    if (destination) {
        return destination
    } else {
        return null
    }
}

model.addItinerary = async (itinerary) => {
    const dbConnect = await dbModule.getItDb();
    const Itinerary = await dbConnect.create(itinerary);
    if (Itinerary) {
        return Itinerary;
    }
}

model.findItinerary = async (id1) => {
    const dbConnect = await dbModule.getItDb();
    const fetchIti = await dbConnect.find({ destinationId: id1 });
    if (fetchIti) {
        return fetchIti;
    }
}

// Favorites Management
model.addFavorite = async (favorite) => {
    const dbConnect = await dbModule.getFavDb();
    const Favorite = await dbConnect.create(favorite);
    if (Favorite) {
        return Favorite;
    }
}

model.getFavorites = async () => {
    const dbConnect = await dbModule.getFavDb();
    const favorites = await dbConnect.find({}, { _id: 0, __v: 0 });
    if (favorites) {
        return favorites;
    }
    return [];
}

model.removeFavorite = async (id) => {
    const dbConnect = await dbModule.getFavDb();
    const removed = await dbConnect.findOneAndDelete({ id: id });
    if (removed) {
        return removed;
    }
}

// Reviews Management
model.addReview = async (review) => {
    const reviewDb = await dbModule.getReviewDb();
    const Review = await reviewDb.create(review);
    if (Review) {
        return Review;
    }
}

model.getReviews = async (filter) => {
    const reviewDb = await dbModule.getReviewDb();
    const itDb = await dbModule.getItDb();
    const dbConnect = await dbModule.getDBModel();

    // If filtering by type and id, query directly
    if (filter.type && filter.id) {
        const reviews = await reviewDb.find({
            type: filter.type,
            id: filter.id
        });
        return reviews || [];
    }

    let destinationIds = [];
    let itineraryIds = [];

    // If filtering by location, find destination ids
    if (filter.location) {
        const destinations = await dbConnect.find({ destinationName: filter.location });
        destinationIds = destinations.map(d => d.destinationId);
    }

    // If filtering by activity, find destination and itinerary ids
    if (filter.activity) {
        const destinations = await dbConnect.find({ activities: filter.activity });
        destinationIds = destinationIds.concat(destinations.map(d => d.destinationId));

        const itineraries = await itDb.find({ activities: filter.activity });
        itineraryIds = itineraries.map(i => i.id);
    }

    // Remove duplicates
    destinationIds = [...new Set(destinationIds)];
    itineraryIds = [...new Set(itineraryIds)];

    // Build query for reviews
    let query = {};
    if (destinationIds.length > 0 || itineraryIds.length > 0) {
        query.$or = [];
        if (destinationIds.length > 0) {
            query.$or.push({ type: "destination-guide", id: { $in: destinationIds } });
        }
        if (itineraryIds.length > 0) {
            query.$or.push({ type: "trip-itinerary", id: { $in: itineraryIds } });
        }
    }

    const reviews = await reviewDb.find(query);
    return reviews || [];
}

model.existingUser = async(userObj)=>{
    try{
        const modelDb = await dbModule.getUserConnection();
        const userData = await modelDb.findOne({email : userObj.email});
        console.log(userData);
        if(userData == null){
           console.log("here")
           return false;
        }else {
           return true;
        }
    }catch(error){
       throw error;
    }
}

model.addUser= async(userObj)=>{
   try{

        const connection = await dbModule.getUserConnection();
        const ack = await connection.create(userObj);
        if(ack){
           return true;
        }else return false;


   }catch(error){
       throw error;
   }
}

model.findUser= async(email)=>{
    try{

        const connection = await dbModule.getUserConnection();
        const ack = await connection.findOne({email : email});
        console.log(ack , "I am Here ")
        if(ack){
           return ack;
        }else return null;


   }catch(error){
       throw error;
   }

}


module.exports = model


