import { useState, useEffect } from "react";
import { FaHeart } from "react-icons/fa";
import axios from "axios";

export default function ItineraryList({ itineraries }) {
    const [favorites, setFavorites] = useState([]);

    useEffect(() => {
        const checkFavorites = async () => {
            try {
                const response = await axios.get("http://localhost:5000/favorites");
                setFavorites(response.data.favorites || []);
            } catch (error) {
                console.error("Error checking favorites:", error);
            }
        };
        checkFavorites();
    }, []);

    const toggleFavorite = async (itinerary) => {
        const isFav = favorites.some(fav => fav.type === "trip-itinerary" && fav.id === itinerary.id);
        try {
            if (isFav) {
                await axios.delete(`http://localhost:5000/favorites/${itinerary.id}`);
                setFavorites(favorites.filter(fav => !(fav.type === "trip-itinerary" && fav.id === itinerary.id)));
            } else {
                await axios.post("http://localhost:5000/favorites", {
                    type: "trip-itinerary",
                    id: itinerary.id
                });
                setFavorites([...favorites, { type: "trip-itinerary", id: itinerary.id }]);
            }
        } catch (error) {
            console.error("Error toggling favorite:", error);
            if (error.response?.status === 401) {
                alert("Please log in to save favorites");
            } else {
                alert("Error saving favorite. Please try again.");
            }
        }
    };

    return (
        <div className="row">
            {itineraries.map((itinerary) => {
                const isFav = favorites.some(fav => fav.type === "trip-itinerary" && fav.id === itinerary.id);
                return (
                    <div key={itinerary.id} className="col-md-6 col-lg-4 mb-4">
                        <div className="card shadow-sm h-100">
                            <div className="card-body">
                                <div className="d-flex justify-content-between align-items-start">
                                    <h5 className="card-title">{itinerary.destination}</h5>
                                    <FaHeart
                                        className={isFav ? "text-danger" : "text-secondary"}
                                        style={{ cursor: "pointer", fontSize: "20px" }}
                                        onClick={() => toggleFavorite(itinerary)}
                                    />
                                </div>
                                <p className="card-text">
                                    <strong>Duration:</strong> {itinerary.duration}
                                </p>
                                <p className="card-text">
                                    <strong>Lodging:</strong> {itinerary.lodging}
                                </p>
                                <p className="card-text">
                                    <strong>Dining:</strong> {itinerary.dining}
                                </p>
                                {itinerary.activities.length > 0 && (
                                    <div className="mb-2">
                                        <strong>Activities:</strong>
                                        <ul className="mt-2">
                                            {itinerary.activities.map((act, i) => (
                                                <li key={i}>{act}</li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
