import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import ReviewForm from "../Destination/ReviewForm";
import { FaHeart } from "react-icons/fa";

export default function ItineraryDetails() {
  const { id } = useParams();
  const [itinerary, setItinerary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isFavorite, setIsFavorite] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [reviewsError, setReviewsError] = useState(null);

  const fetchReviews = async () => {
    setLoadingReviews(true);
    setReviewsError(null);
    try {
      const response = await axios.get("http://localhost:5000/reviews", {
        params: { type: "trip-itinerary", id }
      });
      setReviews(response.data.reviews || []);
    } catch (err) {
      setReviewsError("Failed to load reviews");
      console.error("Error fetching reviews:", err);
    } finally {
      setLoadingReviews(false);
    }
  };

  useEffect(() => {
    const fetchItinerary = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/trip-itineraries/${id}`);
        setItinerary(response.data.itineraries[0]);
      } catch (err) {
        setError("Failed to load itinerary");
        console.error("Error fetching itinerary:", err);
      } finally {
        setLoading(false);
      }
    };

    const checkFavoriteStatus = async () => {
      try {
        const response = await axios.get("http://localhost:5000/favorites");
        const favorites = response.data.favorites || [];
        const isFav = favorites.some(fav => fav.type === "trip-itinerary" && fav.id === Number(id));
        setIsFavorite(isFav);
      } catch (error) {
        console.error("Error checking favorite status:", error);
      }
    };

    fetchItinerary();
    fetchReviews();
    checkFavoriteStatus();
  }, [id]);

  const toggleFavorite = async () => {
    try {
      if (isFavorite) {
        await axios.delete(`http://localhost:5000/favorites/${id}`);
        setIsFavorite(false);
      } else {
        await axios.post("http://localhost:5000/favorites", {
          type: "trip-itinerary",
          id: Number(id)
        });
        setIsFavorite(true);
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      if (error.response?.status === 401) {
        alert("Please log in to save favorites");
      } else {
        alert("Error saving favorite. Please try again.");
      }
    }
  };

  if (loading) {
    return (
      <div className="container text-center my-5">
        <div className="spinner-border text-primary" />
        <p>Loading itinerary...</p>
      </div>
    );
  }

  if (error || !itinerary) {
    return (
      <div className="container my-5 text-center">
        <h3>{error || "Itinerary not found"}</h3>
      </div>
    );
  }

  return (
    <div className="container my-4">
      <div className="d-flex justify-content-between align-items-center">
        <h2>{itinerary.destination} Itinerary</h2>
        <FaHeart
          className={isFavorite ? "text-danger" : "text-secondary"}
          style={{ cursor: "pointer", fontSize: "30px" }}
          onClick={toggleFavorite}
        />
      </div>

      <div className="row">
        <div className="col-md-8">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Trip Details</h5>
              <p><strong>Duration:</strong> {itinerary.duration}</p>
              <p><strong>Lodging:</strong> {itinerary.lodging}</p>
              <p><strong>Dining:</strong> {itinerary.dining}</p>

              {itinerary.activities && itinerary.activities.length > 0 && (
                <div>
                  <strong>Activities:</strong>
                  <ul className="mt-2">
                    {itinerary.activities.map((act, i) => (
                      <li key={i}>{act}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Reviews</h5>
              {loadingReviews ? (
                <p>Loading reviews...</p>
              ) : reviewsError ? (
                <p style={{ color: "red" }}>{reviewsError}</p>
              ) : reviews.length === 0 ? (
                <p>No reviews yet.</p>
              ) : (
                reviews.map((review, index) => (
                  <div key={index} className="border rounded p-2 mb-2">
                    <strong>{review.user || "Anonymous"}</strong> - ⭐ {review.rating}
                    <p>{review.comment}</p>
                  </div>
                ))
              )}
              <ReviewForm
                type="trip-itinerary"
                id={itinerary.id}
                onReviewAdded={() => {
                  // Refresh reviews after adding a new one
                  fetchReviews();
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
