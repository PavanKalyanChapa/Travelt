import { useState, useEffect } from "react";

import { FaStar, FaRegStar, FaHeart } from "react-icons/fa";

import { Link } from "react-router-dom";

import axios from "axios";

import { useAuth } from '../../contexts/AuthContext';

import './DestinationCard.css';





const DestinationCard = ({ guide }) => {

    const { isAuthenticated, token } = useAuth();

    const [isFavorite, setIsFavorite] = useState(false);

    const [loading, setLoading] = useState(false);

    // Check if destination is already in favorites on component mount
    useEffect(() => {
        const checkFavoriteStatus = async () => {
            if (!isAuthenticated || !token) {
                setIsFavorite(false);
                return;
            }
            try {
                const response = await axios.get("http://localhost:5000/favorites", {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const favorites = response.data.favorites || [];
                const isFav = favorites.some(fav => fav.type === "destination-guide" && fav.id === guide.destinationId);
                setIsFavorite(isFav);
            } catch (error) {
                console.error("Error checking favorite status:", error);
                setIsFavorite(false);
            }
        };
        checkFavoriteStatus();
    }, [guide.destinationId, isAuthenticated, token]);

    const toggleFavorite = async () => {
        if (loading) return;

        if (!isAuthenticated) {
            alert("Please log in to save favorites");
            return;
        }

        setLoading(true);
        try {
            if (isFavorite) {
                // Remove from favorites
                await axios.delete(`http://localhost:5000/favorites/${guide.destinationId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setIsFavorite(false);
            } else {
                // Add to favorites
                await axios.post("http://localhost:5000/favorites", {
                    type: "destination-guide",
                    id: guide.destinationId
                }, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setIsFavorite(true);
            }
        } catch (error) {
            console.error("Error toggling favorite:", error);
            if (error.response?.status === 401) {
                alert("Please log in to save favorites");
            } else {
                alert("Error saving favorite. Please try again.");
            }
        } finally {
            setLoading(false);
        }
    }

    const renderStars = (rating) => {

        const fullStars = Math.floor(rating);

        const emptyStars = 5 - fullStars;





        return (

            <>

                {Array(fullStars).fill().map((_, i) => (

                    <FaStar key={`full-${i}`} className="text-warning" />

                ))}

                {Array(emptyStars).fill().map((_, i) => (

                    <FaRegStar key={`empty-${i}`} className="text-warning" />

                ))}

            </>

        );

    };





    return (

        <div className=" tcard" >

            <img

                src={guide.photo}

                className="imag"

                alt={guide.title}

                style={{ height: "200px", objectFit: "cover" }}

            />

            <div className="card-body d-flex flex-column">

                <h5 className="card-title">{guide.title}</h5>

                <p className="card-text mt-2 text-muted">{guide.destinationSummary}</p>

                {/* Ratings & Reviews */}

                <div className="mt-auto  d-flex justify-content-between align-items-center">

                    <div>

                        {renderStars(guide.rating)} {/* hardcoded example: rating=4 */}

                        <small className="text-muted d-block" style={{ marginLeft: "15px" }}>

                            ({guide.reviews.length || 200} reviews)

                        </small>

                    </div>

                    {/* Favorite Icon */}

                    <FaHeart className={isFavorite ? "text-danger" : "text-secondary"} style={{ cursor: "pointer", fontSize: "20px", marginRight: "15px" }} onClick={toggleFavorite} />

                </div>

                <div className="p-3" style={{ height: "40px" }}>

                    <center><Link to={`/destinations/${guide.destinationId}`} className="btt" >View More</Link></center>

                </div>

            </div>

        </div>

    );





};





export default DestinationCard;



