import { useState, useEffect } from "react";

import axios from "axios";

import CreateItinerary from "./createItinerary";

import ItineraryList from "./ItineraryList";




export default function ItineraryTabs({ destination }) {

    const [activeTab, setActiveTab] = useState("view");

    const [itineraries, setItineraries] = useState([]);




    const fetchItineraries = async () => {

        try {

            const res = await axios.get(

                `http://localhost:5000/trip-itineraries${destination.destinationId}`

            );

            setItineraries(res.data ? [res.data] : []);

        } catch (error) {

            console.error(error);

        }

    };




    useEffect(() => {

        if (destination) fetchItineraries();

    }, [destination]);




    const handleItineraryCreated = async () => {

        await fetchItineraries();

        setActiveTab("view");

    };




    return (

        <div className="mt-4">

            <ul className="nav nav-tabs">

                <li className="nav-item">

                    <button

                        className={`nav-link ${activeTab === "view" ? "active" : ""}`}

                        onClick={() => setActiveTab("view")}

                    >

                        View Itineraries

                    </button>

                </li>

                <li className="nav-item">

                    <button

                        className={`nav-link ${activeTab === "create" ? "active" : ""}`}

                        onClick={() => setActiveTab("create")}

                    >

                        Create Itinerary

                    </button>

                </li>

            </ul>




            <div className="tab-content mt-4">

                {activeTab === "view" && (

                    itineraries.length > 0 ? (

                        <ItineraryList itineraries={itineraries} />

                    ) : (

                        <div className="text-center py-4">

                            <p className="text-muted">No itineraries for {destination.destinationName} yet.</p>

                            <button

                                className="btn btn-primary"

                                onClick={() => setActiveTab("create")}

                            >

                                Create Itinerary

                            </button>

                        </div>

                    )

                )}




                {activeTab === "create" && (

                    <CreateItinerary

                        destination={destination}

                        onItineraryCreated={handleItineraryCreated}

                    />

                )}

            </div>

        </div>

    );

}


