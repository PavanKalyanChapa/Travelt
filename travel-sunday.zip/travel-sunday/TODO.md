# TODO: Fix Reviews Filtering in ReviewsPage.jsx

## Completed Tasks
- [x] Analyzed the filtering issue in ReviewsPage.jsx
- [x] Identified that the problem is in the backend model.getReviews function using exact match queries
- [x] Updated model.getReviews to use case-insensitive regex matching for location filters
- [x] Fixed activity filtering by using $elemMatch for array field queries to resolve Mongoose casting error
- [x] Verified the review schema structure from setup_db.js
- [x] Confirmed location filtering is working
- [x] Fixed activity filtering error

## Next Steps
- [ ] Test the activity filtering functionality on the frontend to confirm it works as expected
- [ ] Verify that partial activity names (e.g., "surf" instead of "Surfing") now return reviews
- [ ] Test edge cases like different casing and typos in filter inputs
