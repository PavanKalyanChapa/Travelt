import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from './contexts/AuthContext';
import Home from './home/Home';
import Navbar from './components/navbar/Navbar';
import DestinationDetails from './components/Destination/DestinationDetails';
import CreateItinerary from "./components/itinerary/createItinerary";
import ItineraryPage from "./components/itinerary/ItineraryPage";
import ItineraryDetails from "./components/itinerary/ItineraryDetails";
import ReviewsPage from "./components/Destination/ReviewsPage";
import LoginUser from './components/Auth/loginUser';
import RegisterUser from './components/Auth/registerUser';

function App() {

  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/destinations/:id" element={<DestinationDetails />} />
          <Route path="/create-itinerary/:destinationId" element={<CreateItinerary />} />
          <Route path="/itineraries" element={<ItineraryPage />} />
          <Route path="/itineraries/:id" element={<ItineraryDetails />} />
          <Route path="/reviews" element={<ReviewsPage />} />
          <Route path="/login" element={<LoginUser />} />
          <Route path="/register" element={<RegisterUser />} />
        </Routes>
      </Router>
    </AuthProvider>
  );

}

export default App;
